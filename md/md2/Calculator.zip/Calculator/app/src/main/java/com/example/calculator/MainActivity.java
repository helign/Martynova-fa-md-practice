package com.example.calculator;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import org.mozilla.javascript.Context;
import org.mozilla.javascript.Scriptable;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{

    TextView resultView;
    EditText input_ew;

    Button minus_btn, plus_btn, mul_btn, div_btn, c_btn, ce_btn,
            right_bracket_btn, equals_btn, left_bracket_btn,
            decimal_btn,
            button1, button2, button3, button4, button5, button6,
            button7, button8, button9, button0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        resultView = findViewById(R.id.text_result); //Should show operations
        input_ew = findViewById(R.id.input_ew);

        assignId(minus_btn, R.id.minus_button);
        assignId(plus_btn, R.id.plus_button);
        assignId(mul_btn, R.id.mul_button);
        assignId(div_btn, R.id.div_button);
        assignId(c_btn, R.id.c_button);
        assignId(ce_btn, R.id.ce_button);
        assignId(equals_btn, R.id.equals_button);
        assignId(left_bracket_btn, R.id.left_bracket);
        assignId(decimal_btn, R.id.decim_button);
        assignId(right_bracket_btn, R.id.right_brakcket);
        assignId(button1, R.id.button_1);
        assignId(button2, R.id.button_2);
        assignId(button3, R.id.button_3);
        assignId(button4, R.id.button_4);
        assignId(button5, R.id.button_5);
        assignId(button6, R.id.button_6);
        assignId(button7, R.id.button_7);
        assignId(button8, R.id.button_8);
        assignId(button9, R.id.button_9);
        assignId(button0, R.id.button_0);
    }

    void assignId(Button btn, int id){
        btn = findViewById(id);
        btn.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        Button button = (Button) v;
        String buttonText = (String) button.getText();
        String stuffToCalculate = input_ew.getText().toString();

        if(buttonText.equals("CE")){
            resultView.setText("");
            input_ew.setText("");
            return;
        }
        if(buttonText.equals("=")){
            resultView.setText(input_ew.getText().toString());
        }
        if(buttonText.equals("C")){
            stuffToCalculate = stuffToCalculate.substring(0,stuffToCalculate.length()-1);
        } else {
            stuffToCalculate = stuffToCalculate+buttonText;
        }
        input_ew.setText(stuffToCalculate);

        String finalResult = getResult(stuffToCalculate);

        if(!finalResult.equals("Error")){
            input_ew.setText(finalResult);
        }
    }
    String getResult(String data){
        try {
        Context context = Context.enter();
        context.setOptimizationLevel(-1);
        Scriptable scriptable = context.initSafeStandardObjects();
        return context.evaluateString(scriptable,data,"Javascript",1,null).toString();
        } catch (Exception e) { return "Error";}
    }
}