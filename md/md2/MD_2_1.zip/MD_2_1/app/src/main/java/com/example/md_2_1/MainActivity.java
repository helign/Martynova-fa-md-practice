package com.example.md_2_1;

import android.content.res.Resources;
import android.os.Bundle;
import android.view.View;
import android.view.ViewDebug;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    ImageButton mainBtn;
    Button zeroBtn,minusBtn;

    private long score = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        TextView main_text = findViewById(R.id.main_text);

        mainBtn = (ImageButton) findViewById(R.id.main_btn);
        mainBtn.setOnClickListener(clickListener);

        minusBtn = (Button) findViewById(R.id.decount_btn);
        minusBtn.setOnClickListener(clickListener);

        zeroBtn = (Button) findViewById(R.id.erase_btn);
        zeroBtn.setOnClickListener(clickListener);
    }

    View.OnClickListener clickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            TextView main_text = findViewById(R.id.main_text);;
            if (v.getId() == R.id.main_btn) {
                score ++;
                            }
            else if (v.getId() == R.id.decount_btn) {
                score --;
                            }
            else if (v.getId() == R.id.erase_btn) {
                score = 0;
            }
            String s = getResources().getString(R.string.clicks_0) + score;
            main_text.setText(s);
        }
    };

}